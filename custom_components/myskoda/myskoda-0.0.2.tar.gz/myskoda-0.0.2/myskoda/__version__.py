"""Version for MySkoda package. Used for dynamic versioning with poetry."""

__version__ = "0.0.0"
