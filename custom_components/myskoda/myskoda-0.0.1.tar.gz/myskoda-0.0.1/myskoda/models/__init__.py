"""Pydantic models for all API responses."""
